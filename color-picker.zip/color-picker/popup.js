// popup.js — Quick Color Picker
// Converts a chosen color to HEX/RGB and copies to clipboard.
// Saves recent colors to local storage. No network requests. No eval.

const MAX_RECENT = 10;

function hexToRgb(hex) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${r},${g},${b})`;
}

function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  setTimeout(() => { toast.textContent = ""; }, 1500);
}

function renderSwatches(recents) {
  const container = document.getElementById("swatches");
  container.innerHTML = "";
  recents.forEach((color) => {
    const swatch = document.createElement("div");
    swatch.className = "swatch";
    swatch.style.background = color;
    swatch.title = color;
    swatch.addEventListener("click", () => {
      document.getElementById("colorInput").value = color;
      updateOutputs(color);
    });
    container.appendChild(swatch);
  });
}

function saveRecent(hex) {
  chrome.storage.local.get("recentColors", (result) => {
    let recents = result.recentColors || [];
    recents = [hex, ...recents.filter((c) => c !== hex)].slice(0, MAX_RECENT);
    chrome.storage.local.set({ recentColors: recents });
    renderSwatches(recents);
  });
}

function updateOutputs(hex) {
  document.getElementById("hexValue").textContent = hex;
  document.getElementById("rgbValue").textContent = hexToRgb(hex);
}

document.addEventListener("DOMContentLoaded", () => {
  const colorInput = document.getElementById("colorInput");

  chrome.storage.local.get(["lastColor", "recentColors"], (result) => {
    if (result.lastColor) {
      colorInput.value = result.lastColor;
      updateOutputs(result.lastColor);
    } else {
      updateOutputs(colorInput.value);
    }
    renderSwatches(result.recentColors || []);
  });

  colorInput.addEventListener("input", () => {
    updateOutputs(colorInput.value);
  });

  colorInput.addEventListener("change", () => {
    const hex = colorInput.value;
    chrome.storage.local.set({ lastColor: hex });
    saveRecent(hex);
  });

  document.getElementById("copyHex").addEventListener("click", () => {
    navigator.clipboard.writeText(document.getElementById("hexValue").textContent);
    showToast("HEX copied!");
  });

  document.getElementById("copyRgb").addEventListener("click", () => {
    navigator.clipboard.writeText(document.getElementById("rgbValue").textContent);
    showToast("RGB copied!");
  });
});
