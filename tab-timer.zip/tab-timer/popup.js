// popup.js — reads open-time from local storage and renders elapsed time.
// No network requests. No external calls. Pure local storage read.

function formatDuration(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const hours   = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}

document.addEventListener("DOMContentLoaded", () => {
  const elapsedEl = document.getElementById("elapsed");
  const openedEl  = document.getElementById("opened");

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    if (!currentTab) return;

    chrome.storage.local.get("tabOpenTimes", (result) => {
      const times = result.tabOpenTimes || {};
      const openedAt = times[currentTab.id];

      if (openedAt) {
        const elapsed = Date.now() - openedAt;
        elapsedEl.textContent = formatDuration(elapsed);
        const openedDate = new Date(openedAt);
        openedEl.textContent = "Opened at " + openedDate.toLocaleTimeString();
      } else {
        elapsedEl.textContent = "Unknown";
        openedEl.textContent = "No data for this tab";
      }
    });
  });
});
