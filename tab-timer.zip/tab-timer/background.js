// background.js — Tab Timer
// Records the timestamp when each tab is created.
// No network requests. No external domains. No eval. No cookies.

const TAB_OPEN_TIMES_KEY = "tabOpenTimes";

function getStoredTimes(callback) {
  chrome.storage.local.get(TAB_OPEN_TIMES_KEY, (result) => {
    callback(result[TAB_OPEN_TIMES_KEY] || {});
  });
}

function saveTimes(times) {
  chrome.storage.local.set({ [TAB_OPEN_TIMES_KEY]: times });
}

// Record when a new tab is opened
chrome.tabs.onCreated.addListener((tab) => {
  getStoredTimes((times) => {
    times[tab.id] = Date.now();
    saveTimes(times);
  });
});

// Clean up when a tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
  getStoredTimes((times) => {
    delete times[tabId];
    saveTimes(times);
  });
});

// Initialize tracking for existing tabs on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.query({}, (tabs) => {
    const times = {};
    const now = Date.now();
    tabs.forEach((tab) => {
      times[tab.id] = now;
    });
    saveTimes(times);
  });
});
