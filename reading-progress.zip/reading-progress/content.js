// content.js — Reading Progress Bar
// Injects a thin progress bar that reflects scroll position on any page.
// No network requests. No external calls. No storage. No eval.

(function () {
  // Avoid injecting twice (e.g. on SPA navigation)
  if (document.getElementById("rdp-bar-container")) return;

  const container = document.createElement("div");
  container.id = "rdp-bar-container";

  const bar = document.createElement("div");
  bar.id = "rdp-bar";

  container.appendChild(bar);
  document.documentElement.appendChild(container);

  function updateBar() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress  = docHeight > 0 ? Math.min(scrollTop / docHeight, 1) : 0;
    bar.style.width = (progress * 100) + "%";
  }

  window.addEventListener("scroll", updateBar, { passive: true });
  window.addEventListener("resize", updateBar, { passive: true });
  updateBar();
})();
