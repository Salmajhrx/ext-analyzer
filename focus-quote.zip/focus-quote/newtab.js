// newtab.js — Focus Quote
// Displays time and a daily quote from a local bundle.
// No network requests. No external calls. No eval.

const QUOTES = [
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Our greatest glory is not in never falling, but in rising every time we fall.", author: "Confucius" },
  { text: "You are never too old to set another goal or to dream a new dream.", author: "C.S. Lewis" },
  { text: "The future depends on what you do today.", author: "Mahatma Gandhi" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
  { text: "Success is not final; failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela" },
  { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson" },
  { text: "Act as if what you do makes a difference. It does.", author: "William James" },
  { text: "With the new day comes new strength and new thoughts.", author: "Eleanor Roosevelt" },
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Keep your eyes on the stars and your feet on the ground.", author: "Theodore Roosevelt" },
  { text: "What you get by achieving your goals is not as important as what you become.", author: "Henry David Thoreau" },
  { text: "Hardships often prepare ordinary people for an extraordinary destiny.", author: "C.S. Lewis" },
  { text: "You don't have to be great to start, but you have to start to be great.", author: "Zig Ziglar" },
  { text: "In the middle of every difficulty lies opportunity.", author: "Albert Einstein" },
  { text: "Either you run the day, or the day runs you.", author: "Jim Rohn" },
  { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb" },
  { text: "An unexamined life is not worth living.", author: "Socrates" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "Simplicity is the ultimate sophistication.", author: "Leonardo da Vinci" },
  { text: "Spread love everywhere you go.", author: "Mother Teresa" },
  { text: "When you reach the end of your rope, tie a knot in it and hang on.", author: "Franklin D. Roosevelt" },
  { text: "Always remember that you are absolutely unique. Just like everyone else.", author: "Margaret Mead" },
  { text: "Do not go where the path may lead; go instead where there is no path and leave a trail.", author: "Ralph Waldo Emerson" },
  { text: "No act of kindness, no matter how small, is ever wasted.", author: "Aesop" },
  { text: "We know what we are, but know not what we may be.", author: "William Shakespeare" },
  { text: "To thine own self be true.", author: "William Shakespeare" },
  { text: "Be yourself; everyone else is already taken.", author: "Oscar Wilde" }
];

function getDailyQuote() {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0)) / 86400000
  );
  return QUOTES[dayOfYear % QUOTES.length];
}

function padTwo(n) {
  return String(n).padStart(2, "0");
}

function updateClock() {
  const now = new Date();
  const h = padTwo(now.getHours());
  const m = padTwo(now.getMinutes());
  document.getElementById("time").textContent = `${h}:${m}`;
}

document.addEventListener("DOMContentLoaded", () => {
  const entry = getDailyQuote();
  document.getElementById("quote").textContent  = `"${entry.text}"`;
  document.getElementById("author").textContent = `— ${entry.author}`;

  updateClock();
  setInterval(updateClock, 10000);

  // Persist view count locally (no analytics sent anywhere)
  chrome.storage.local.get("viewCount", (result) => {
    const count = (result.viewCount || 0) + 1;
    chrome.storage.local.set({ viewCount: count });
  });
});
